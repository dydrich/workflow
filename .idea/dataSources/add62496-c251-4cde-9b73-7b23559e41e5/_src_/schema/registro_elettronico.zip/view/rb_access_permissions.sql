CREATE VIEW rb_access_permissions AS
  SELECT `registro_elettronico`.`rb_ruoli`.`permessi` AS `permessi`
  FROM `registro_elettronico`.`rb_ruoli`
  UNION SELECT `perms`.`permessi` AS `permessi`
        FROM `registro_elettronico`.`rb_gruppi` `perms`;
