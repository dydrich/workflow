CREATE VIEW rb_genitori AS
  SELECT
    `registro_elettronico`.`rb_utenti`.`uid`             AS `uid`,
    `registro_elettronico`.`rb_utenti`.`username`        AS `username`,
    `registro_elettronico`.`rb_utenti`.`password`        AS `password`,
    `registro_elettronico`.`rb_utenti`.`nome`            AS `nome`,
    `registro_elettronico`.`rb_utenti`.`cognome`         AS `cognome`,
    `registro_elettronico`.`rb_utenti`.`accessi`         AS `accessi`,
    `registro_elettronico`.`rb_utenti`.`permessi`        AS `permessi`,
    `registro_elettronico`.`rb_utenti`.`last_access`     AS `last_access`,
    `registro_elettronico`.`rb_utenti`.`previous_access` AS `previous_access`
  FROM (`registro_elettronico`.`rb_utenti`
    JOIN `registro_elettronico`.`rb_gruppi_utente`)
  WHERE ((`registro_elettronico`.`rb_utenti`.`uid` = `registro_elettronico`.`rb_gruppi_utente`.`uid`) AND
         (`registro_elettronico`.`rb_gruppi_utente`.`gid` = 4));
