CREATE VIEW rb_vclassi_s2 AS
  SELECT
    `registro_elettronico`.`rb_classi`.`id_classe`        AS `id_classe`,
    `registro_elettronico`.`rb_classi`.`anno_corso`       AS `anno_corso`,
    `registro_elettronico`.`rb_classi`.`sezione`          AS `sezione`,
    `registro_elettronico`.`rb_classi`.`anno_scolastico`  AS `anno_scolastico`,
    `registro_elettronico`.`rb_classi`.`tempo_prolungato` AS `tempo_prolungato`,
    `registro_elettronico`.`rb_classi`.`sede`             AS `sede`,
    `registro_elettronico`.`rb_classi`.`musicale`         AS `musicale`,
    `registro_elettronico`.`rb_classi`.`modulo_orario`    AS `modulo_orario`,
    `registro_elettronico`.`rb_classi`.`ordine_di_scuola` AS `ordine_di_scuola`,
    `registro_elettronico`.`rb_classi`.`coordinatore`     AS `coordinatore`,
    `registro_elettronico`.`rb_classi`.`segretario`       AS `segretario`
  FROM `registro_elettronico`.`rb_classi`
  WHERE (`registro_elettronico`.`rb_classi`.`ordine_di_scuola` = 2);
