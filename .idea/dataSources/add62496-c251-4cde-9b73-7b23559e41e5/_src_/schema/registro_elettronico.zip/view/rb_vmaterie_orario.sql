CREATE VIEW rb_vmaterie_orario AS
  SELECT
    `registro_elettronico`.`rb_materie`.`id_materia`       AS `id_materia`,
    `registro_elettronico`.`rb_materie`.`materia`          AS `materia`,
    `registro_elettronico`.`rb_materie`.`idpadre`          AS `idpadre`,
    `registro_elettronico`.`rb_materie`.`has_sons`         AS `has_sons`,
    `registro_elettronico`.`rb_materie`.`pagella`          AS `pagella`,
    `registro_elettronico`.`rb_materie`.`tipologia_scuola` AS `tipologia_scuola`
  FROM `registro_elettronico`.`rb_materie`
  WHERE (
    (`registro_elettronico`.`rb_materie`.`id_materia` <> 2) AND (`registro_elettronico`.`rb_materie`.`id_materia` <> 27)
    AND
    ((`registro_elettronico`.`rb_materie`.`idpadre` <> 13) OR isnull(`registro_elettronico`.`rb_materie`.`idpadre`)));
