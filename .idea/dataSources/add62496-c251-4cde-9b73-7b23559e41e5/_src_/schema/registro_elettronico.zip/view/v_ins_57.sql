CREATE VIEW v_ins_57 AS
  SELECT
    `registro_elettronico`.`rb_scrutini`.`alunno`                                                           AS `alunno`,
    concat_ws(' ', `registro_elettronico`.`rb_alunni`.`cognome`, `registro_elettronico`.`rb_alunni`.`nome`) AS `al`,
    `registro_elettronico`.`rb_scrutini`.`classe`                                                           AS `classe`,
    avg(
        `registro_elettronico`.`rb_scrutini`.`voto`)                                                        AS `AVG(voto)`,
    concat(`registro_elettronico`.`rb_classi`.`anno_corso`,
           `registro_elettronico`.`rb_classi`.`sezione`)                                                    AS `desc_classe`
  FROM ((`registro_elettronico`.`rb_scrutini`
    JOIN `registro_elettronico`.`rb_classi`) JOIN `registro_elettronico`.`rb_alunni`)
  WHERE ((`registro_elettronico`.`rb_scrutini`.`alunno` = `registro_elettronico`.`rb_alunni`.`id_alunno`) AND
         (`registro_elettronico`.`rb_scrutini`.`classe` = `registro_elettronico`.`rb_classi`.`id_classe`) AND
         (`registro_elettronico`.`rb_scrutini`.`quadrimestre` = 2))
  GROUP BY `registro_elettronico`.`rb_scrutini`.`alunno`, `registro_elettronico`.`rb_scrutini`.`classe`
  HAVING ((avg(`registro_elettronico`.`rb_scrutini`.`voto`) < 5.7) AND
          (avg(`registro_elettronico`.`rb_scrutini`.`voto`) > 0))
  ORDER BY `registro_elettronico`.`rb_classi`.`anno_corso`, `registro_elettronico`.`rb_classi`.`sezione`;
