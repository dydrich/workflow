CREATE VIEW v_num_insuff AS
  SELECT
    `registro_elettronico`.`rb_scrutini`.`alunno`                                                           AS `alunno`,
    concat_ws(' ', `registro_elettronico`.`rb_alunni`.`cognome`, `registro_elettronico`.`rb_alunni`.`nome`) AS `al`,
    `registro_elettronico`.`rb_scrutini`.`classe`                                                           AS `classe`,
    count(`registro_elettronico`.`rb_scrutini`.`voto`)                                                      AS `ins`,
    concat(`registro_elettronico`.`rb_classi`.`anno_corso`,
           `registro_elettronico`.`rb_classi`.`sezione`)                                                    AS `desc_classe`
  FROM ((`registro_elettronico`.`rb_scrutini`
    JOIN `registro_elettronico`.`rb_classi`) JOIN `registro_elettronico`.`rb_alunni`)
  WHERE ((`registro_elettronico`.`rb_scrutini`.`alunno` = `registro_elettronico`.`rb_alunni`.`id_alunno`) AND
         (`registro_elettronico`.`rb_scrutini`.`classe` = `registro_elettronico`.`rb_classi`.`id_classe`) AND
         (`registro_elettronico`.`rb_scrutini`.`quadrimestre` = 2) AND
         (`registro_elettronico`.`rb_scrutini`.`voto` < 6))
  GROUP BY `registro_elettronico`.`rb_scrutini`.`alunno`, `registro_elettronico`.`rb_scrutini`.`classe`
  ORDER BY `registro_elettronico`.`rb_classi`.`anno_corso`, `registro_elettronico`.`rb_classi`.`sezione`;
